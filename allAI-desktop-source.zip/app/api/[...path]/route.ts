import {env} from 'cloudflare:workers';
import {sendOpenRouterChat, OpenRouterRequestError, type ChatMessage} from '../../../lib/openrouter';
export const dynamic = 'force-dynamic';
const E=()=>env as unknown as {DB:D1Database;OPENROUTER_API_KEY?:string;GOOGLE_CLIENT_ID?:string;GOOGLE_CLIENT_SECRET?:string};
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const cookie=(r:Request,k:string)=>r.headers.get('cookie')?.split(';').map(v=>v.trim()).find(v=>v.startsWith(k+'='))?.slice(k.length+1);
const sessionCookie=(id:string,age=2592000)=>`allai_session=${id}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${age}`;
async function user(r:Request){
 const sid=cookie(r,'allai_session');
 if(sid){const u=await E().DB.prepare('SELECT users.id,users.email,users.name FROM sessions JOIN users ON sessions.user_id=users.id WHERE sessions.id=? AND expires>?').bind(sid,Date.now()).first();if(u)return u as {id:string;email:string;name:string};}
 const id=r.headers.get('oai-authenticated-user-id');
 if(id){const email=r.headers.get('oai-authenticated-user-email')||'';let name=r.headers.get('oai-authenticated-user-full-name')||email.split('@')[0]||'Участник';try{if(r.headers.get('oai-authenticated-user-full-name-encoding')==='percent-encoded-utf-8')name=decodeURIComponent(name);}catch{}return {id:'sites:'+id,email,name};}
 return null;
}
async function hash(password:string,salt:string){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);return Array.from(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:new TextEncoder().encode(salt),iterations:100000},key,256))).map(v=>v.toString(16).padStart(2,'0')).join('');}
async function login(id:string){const token=crypto.randomUUID()+crypto.randomUUID();await E().DB.prepare('INSERT INTO sessions(id,user_id,expires) VALUES(?,?,?)').bind(token,id,Date.now()+2592000000).run();return token;}
let cached:{models:unknown[];at:number}|null=null;
async function catalog(){if(cached&&Date.now()-cached.at<300000)return cached.models;const r=await fetch('https://openrouter.ai/api/v1/models',{signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('Не удалось обновить каталог');const body=await r.json() as {data:any[]};cached={models:body.data,at:Date.now()};return body.data;}
export async function GET(r:Request){try{
 const p=new URL(r.url).pathname;
 if(p==='/api/models'){try{return json({models:await catalog(),live:true});}catch{return json({models:[],live:false});}}
 if(p==='/api/me')return json({user:await user(r),google:!!(E().GOOGLE_CLIENT_ID&&E().GOOGLE_CLIENT_SECRET),free:!!E().OPENROUTER_API_KEY});
 if(p==='/api/auth/google'){
  if(!E().GOOGLE_CLIENT_ID||!E().GOOGLE_CLIENT_SECRET)return json({error:'Google-вход ещё не подключён владельцем сайта.'},503);
  const state=crypto.randomUUID();const url=new URL('https://accounts.google.com/o/oauth2/v2/auth');url.search=new URLSearchParams({client_id:E().GOOGLE_CLIENT_ID!,redirect_uri:new URL('/api/auth/google/callback',r.url).href,response_type:'code',scope:'openid email profile',state}).toString();return new Response(null,{status:302,headers:{Location:url.href,'Set-Cookie':`allai_oauth=${state}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=600`}});
 }
 if(p==='/api/auth/google/callback'){
  const u=new URL(r.url);if(!u.searchParams.get('state')||u.searchParams.get('state')!==cookie(r,'allai_oauth'))return json({error:'Недействительная OAuth-сессия'},400);
  const tr=await fetch('https://oauth2.googleapis.com/token',{method:'POST',body:new URLSearchParams({client_id:E().GOOGLE_CLIENT_ID!,client_secret:E().GOOGLE_CLIENT_SECRET!,code:u.searchParams.get('code')||'',redirect_uri:new URL('/api/auth/google/callback',r.url).href,grant_type:'authorization_code'}),signal:AbortSignal.timeout(15000)});
  const t=await tr.json() as any;if(!tr.ok||!t.access_token)return json({error:'Google не подтвердил вход'},400);
  const ur=await fetch('https://openidconnect.googleapis.com/v1/userinfo',{headers:{Authorization:`Bearer ${t.access_token}`},signal:AbortSignal.timeout(15000)});const gu=await ur.json() as any;if(!ur.ok||!gu.email_verified)return json({error:'Подтверди адрес в Google'},400);
  let found=await E().DB.prepare('SELECT id,password FROM users WHERE email=?').bind(gu.email.toLowerCase()).first<{id:string;password?:string}>();
  if(found?.password)return json({error:'Для этой почты уже создан аккаунт с паролем. Войди с паролем. Автоматическое объединение аккаунтов отключено.'},409);
  if(!found){found={id:crypto.randomUUID()};await E().DB.prepare('INSERT INTO users(id,email,name) VALUES(?,?,?)').bind(found.id,gu.email.toLowerCase(),gu.name||gu.email.split('@')[0]).run();}
  const headers=new Headers({Location:'/'});headers.append('Set-Cookie',sessionCookie(await login(found.id)));headers.append('Set-Cookie','allai_oauth=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0');return new Response(null,{status:302,headers});
 }
 const me=await user(r);if(!me)return json({error:'Войди в аккаунт, чтобы сохранять чаты и общаться.'},401);
 if(p==='/api/chats')return json({chats:(await E().DB.prepare('SELECT * FROM chats WHERE user_id=? ORDER BY updated DESC LIMIT 100').bind(me.id).all()).results});
 if(p.startsWith('/api/chats/')){const id=p.split('/').pop();const chat=await E().DB.prepare('SELECT * FROM chats WHERE id=? AND user_id=?').bind(id,me.id).first();if(!chat)return json({error:'Чат не найден'},404);return json({chat,messages:(await E().DB.prepare('SELECT * FROM messages WHERE chat_id=? ORDER BY created,id').bind(id).all()).results});}
 if(p==='/api/community')return json({messages:(await E().DB.prepare('SELECT id,name,content,created FROM community ORDER BY created DESC LIMIT 100').all()).results.reverse()});
 return json({error:'Не найдено'},404);
}catch{return json({error:'Сервис временно недоступен. Попробуй ещё раз.'},503);}}
export async function POST(r:Request){try{
 if(r.headers.get('origin')!==new URL(r.url).origin)return json({error:'Недопустимый источник запроса'},403);
 if(Number(r.headers.get('content-length')||0)>250000)return json({error:'Слишком большой запрос'},413);
 const p=new URL(r.url).pathname;const b=await r.json() as any;
 if(p==='/api/auth/register'||p==='/api/auth/login'){
  const email=String(b.email||'').trim().toLowerCase();const password=String(b.password||'');if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254||password.length<10||password.length>128)return json({error:'Укажи корректную почту и пароль от 10 до 128 символов.'},400);
  const rateKey='auth:'+email;const now=Date.now();
  await E().DB.prepare('INSERT INTO attempts(id,count,reset) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=CASE WHEN reset<? THEN 1 ELSE count+1 END,reset=CASE WHEN reset<? THEN ? ELSE reset END').bind(rateKey,now+600000,now,now,now+600000).run();
  const recent=await E().DB.prepare('SELECT count FROM attempts WHERE id=?').bind(rateKey).first<{count:number}>();if((recent?.count||0)>10)return json({error:'Слишком много попыток. Попробуй через 10 минут.'},429);
  let u=await E().DB.prepare('SELECT * FROM users WHERE email=?').bind(email).first<any>();
  if(p.endsWith('register')){if(u)return json({error:'Аккаунт уже существует. Попробуй войти.'},409);const salt=crypto.randomUUID();u={id:crypto.randomUUID(),name:String(b.name||email.split('@')[0]).trim().slice(0,60)||'Участник'};await E().DB.prepare('INSERT INTO users(id,email,name,password,salt) VALUES(?,?,?,?,?)').bind(u.id,email,u.name,await hash(password,salt),salt).run();}
  else if(!u?.password||await hash(password,u.salt)!==u.password)return json({error:'Неверная почта или пароль.'},401);
  return new Response(JSON.stringify({user:{id:u.id,name:u.name,email}}),{headers:{'Content-Type':'application/json','Cache-Control':'no-store','Set-Cookie':sessionCookie(await login(u.id))}});
 }
 if(p==='/api/auth/logout'){const sid=cookie(r,'allai_session');if(sid)await E().DB.prepare('DELETE FROM sessions WHERE id=?').bind(sid).run();return new Response('{}',{headers:{'Set-Cookie':sessionCookie('',0)}});}
 const me=await user(r);if(!me)return json({error:'Сначала войди в аккаунт.'},401);
 if(p==='/api/community'){
  const content=String(b.content||'').trim();if(!content||content.length>2000)return json({error:'Сообщение должно содержать от 1 до 2000 символов.'},400);
  const last=await E().DB.prepare('SELECT created FROM community WHERE user_id=? ORDER BY created DESC LIMIT 1').bind(me.id).first<{created:number}>();if(last&&Date.now()-last.created<2000)return json({error:'Подожди пару секунд перед следующим сообщением.'},429);
  await E().DB.prepare('INSERT INTO community(id,user_id,name,content,created) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),me.id,me.name,content,Date.now()).run();return json({ok:true});
 }
 if(p==='/api/chat'){
  const content=String(b.content||'').trim();const model=String(b.model||'openrouter/free');if(!content||content.length>16000)return json({error:'Сообщение должно содержать от 1 до 16 000 символов.'},400);
  const key=String(b.apiKey||E().OPENROUTER_API_KEY||'');if(!key)return json({error:'Добавь свой OpenRouter API key в настройках. Бесплатный тест за счёт сайта пока не подключён.'},402);
  if(!b.apiKey&&model!=='openrouter/free'){const all=await catalog() as any[];const m=all.find(v=>v.id===model);if(!m||Number(m.pricing?.prompt)!==0||Number(m.pricing?.completion)!==0)return json({error:'Для платной модели нужен твой API key.'},402);}
  const id=b.chatId||crypto.randomUUID();const existing=await E().DB.prepare('SELECT * FROM chats WHERE id=?').bind(id).first<any>();if(existing&&existing.user_id!==me.id)return json({error:'Чат не найден'},404);
  const history=existing?(await E().DB.prepare('SELECT role,content FROM messages WHERE chat_id=? ORDER BY created,id').bind(id).all()).results:[];
  // Preserve the entire conversation; reject oversized history instead of silently truncating.
  if(JSON.stringify(history).length>500000)return json({error:'Диалог слишком большой. Начни новый чат или выбери модель с большим контекстом.'},413);
  const result=await sendOpenRouterChat({apiKey:key,model,messages:[...history as ChatMessage[],{role:'user',content}],referer:new URL(r.url).origin});
  const answer=result.content;
  const now=Date.now();const statements=[];if(!existing)statements.push(E().DB.prepare('INSERT INTO chats(id,user_id,title,model,updated) VALUES(?,?,?,?,?)').bind(id,me.id,content.slice(0,70),model,now));else statements.push(E().DB.prepare('UPDATE chats SET model=?,updated=? WHERE id=? AND user_id=?').bind(model,now,id,me.id));
  statements.push(E().DB.prepare('INSERT INTO messages(id,chat_id,role,content,model,created) VALUES(?,?,?,?,?,?)').bind(crypto.randomUUID(),id,'user',content,model,now));statements.push(E().DB.prepare('INSERT INTO messages(id,chat_id,role,content,model,created) VALUES(?,?,?,?,?,?)').bind(crypto.randomUUID(),id,'assistant',answer,model,now+1));await E().DB.batch(statements);return json({chatId:id,content:answer,model});
 }
 if(p==='/api/chats/delete'){await E().DB.batch([E().DB.prepare('DELETE FROM messages WHERE chat_id IN (SELECT id FROM chats WHERE id=? AND user_id=?)').bind(b.id,me.id),E().DB.prepare('DELETE FROM chats WHERE id=? AND user_id=?').bind(b.id,me.id)]);return json({ok:true});}
 return json({error:'Не найдено'},404);
}catch(e){if(e instanceof OpenRouterRequestError)return json({error:e.message},e.status);return json({error:e instanceof Error&&e.name==='TimeoutError'?'Модель отвечает слишком долго. Попробуй ещё раз.':'Запрос не выполнен. Попробуй ещё раз.'},503);}}
